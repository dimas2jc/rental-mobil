$(document).ready(function(){
    $("#booking").addClass("active")
})