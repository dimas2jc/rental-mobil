<?php $__env->startSection('content-data-master'); ?>

<div class="card">
    <div class="card-body">
        <div class="judul-tabel mb-3">
            <h5>Daftar Harga Kendaraan</h5>
            <button class="btn btn-sm btn-rounded bg-dribbble ml-auto tombol-tambah-harga" data-toggle="modal" data-target="#modal-tambah-harga">
                <i class="fa fa-plus mr-1"></i>
                TAMBAH BARU
            </button>
        </div>
        <table id="table-harga" class="table table-striped table-bordered responsive" style="width: 100%">
            <thead class="thead-dark">
                <tr>
                    <th>No. Polisi</th>
                    <th>Varian</th>
                    <th>Kapasitas BBM</th>
                    <th>Harga</th>
                    <th>Waktu/Jam</th>
                    <th style="width: 10%">Actions</th>
                </tr>
            </thead>
        </table>
    </div>
</div>


<div class="modal fade" id="modal-tambah-harga" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-secondary">
                <h5 class="modal-title" id="judul-modal"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="fa fa-times-circle text-danger"></i>
                </button>
            </div>
            <form action="" id="formHarga" method="POST" class="needs-validation" novalidate>
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="" class="col-form-label">
                            Kendaraan
                        </label>
                        <select class="form-control select-component select-kendaraan <?php $__errorArgs = ['kendaraan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="" name="kendaraan" required>
                            <option selected disabled>Pilih Kendaraan . . </option>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->ID_VEHICLES); ?>"><?php echo e($d->NOPOL); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="invalid-feedback">
                            Mohon isi kendaraan dengan benar.
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="" class="col-form-label">
                            Harga
                        </label>
                        <input type="text" name="harga" id="harga" class="form-control <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <div class="invalid-feedback">
                            Mohon isi harga dengan benar.
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-form-label">
                            Waktu/Jam
                        </label>
                        <input type="text" name="waktu" id="waktu" class="form-control <?php $__errorArgs = ['waktu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <div class="invalid-feedback">
                            Mohon isi waktu dengan benar.
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-google btn-sm" onclick="document.getElementById('insert-form-customer').reset(); $('#modal-tambah-customer').modal('toggle');">BATAL</button>
                    <button type="submit" class="btn btn-linkedin btn-sm">SIMPAN</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-script'); ?>
    <script src="<?php echo e(asset('assets/js/examples/file-manager.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom/data_master_harga_kendaraan.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom/data_master.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('data_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyek\rental-mobil\resources\views/data_master_harga_kendaraan.blade.php ENDPATH**/ ?>