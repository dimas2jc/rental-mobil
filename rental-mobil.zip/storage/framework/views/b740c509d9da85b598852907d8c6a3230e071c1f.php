<?php $__env->startSection('content-data-master'); ?>

<div class="card">
    <div class="card-body">
        <form action="<?php echo e(url('setting/company')); ?>" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="icon">Logo <?php echo e(env('NAMA_PERUSAHAAN')); ?></label>
                <input type="file" accept="img/*" id="file" name="file" class="form-control <?php $__errorArgs = ['fil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                <div class="invalid-feedback">
                    Mohon isi file dengan benar.
                </div>
                <small class="form-text text-muted">Maksimal 2MB.</small>
            </div>
            <div class="form-group">
                <label for="nama perusahaan">Nama Perusahaan</label>
                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" required>
                <div class="invalid-feedback">
                    Mohon isi nama perusahaan dengan benar.
                </div>
            </div>
            <div class="form-group">
                <label for="">No. Telpon Perusahaan</label>
                <input type="text" class="form-control <?php $__errorArgs = ['no_telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_telp" name="no_telp" required>
                <div class="invalid-feedback">
                    Mohon isi nomor telpon dengan benar.
                </div>
            </div>
            <div class="form-group">
                <label for="">Email Perusahaan</label>
                <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" required>
                <div class="invalid-feedback">
                    Mohon isi email dengan benar.
                </div>
            </div>
            <div class="form-group">
                <label for="">Alamat Perusahaan</label>
                <input type="text" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="alamat" required>
                <div class="invalid-feedback">
                    Mohon isi alamat dengan benar.
                </div>
            </div>
            <button type="submit" id="formSubmit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-script'); ?>
    <script src="<?php echo e(asset('assets/js/examples/file-manager.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom/data_master_setting.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom/data_master.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('data_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyek\rental-mobil\resources\views/data_master_setting.blade.php ENDPATH**/ ?>