<?php $__env->startSection('extra-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendors/prism/prism.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row no-gutters app-block">
    <div class="col-md-2 app-sidebar">
        <div class="app-sidebar-menu">
            <div>
                <div class="list-group list-group-flush">
                    <a href="<?php echo e(url('/data_master/settings')); ?>" class="list-group-item d-flex align-items-center" id="setting">
                        <i class="ti-settings mr-2 list-group-icon"></i>Setting
                    </a>
                    
                    <a href="<?php echo e(url('/data_master/employes')); ?>" class="list-group-item d-flex align-items-center" id="pegawai">
                        <i class="ti-user mr-2 list-group-icon"></i>Pegawai
                        <span class="small ml-auto" id="total_pegawai">0</span>
                    </a>
                    <a href="<?php echo e(url('/data_master/pemilik-kendaraan')); ?>" class="list-group-item d-flex align-items-center" id="vendor">
                        <i class="ti-star mr-2 list-group-icon"></i>Pemilik Kendaraan
                        <span class="small ml-auto" id="total_vendor">0</span>
                    </a>
                    <a href="<?php echo e(url('/data_master/kendaraan')); ?>" class="list-group-item d-flex align-items-center" id="kendaraan">
                        <i class="ti-car mr-2 list-group-icon"></i>Kendaraan
                        <span class="small ml-auto" id="total_kendaraan">0</span>
                    </a>
                    <a href="<?php echo e(url('/data_master/harga-kendaraan')); ?>" class="list-group-item d-flex align-items-center" id="harga_kendaraan">
                        <i class="ti-money mr-2 list-group-icon"></i>Harga Kendaraan
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-10 app-content">
        <?php echo $__env->yieldContent('content-data-master'); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-script'); ?>
    <script src="<?php echo e(asset('vendors/prism/prism.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyek\rental-mobil\resources\views/data_master.blade.php ENDPATH**/ ?>