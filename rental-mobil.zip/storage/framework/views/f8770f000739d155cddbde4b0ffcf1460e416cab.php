

<?php $__env->startSection('extra-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendors/prism/prism.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row no-gutters app-block">
    <div class="col-md-2 app-sidebar">
        <div class="app-sidebar-menu">
            <div>
                <div class="list-group list-group-flush">
                    <a href="<?php echo e(url('/data_master/users')); ?>" class="list-group-item d-flex align-items-center" id="manajemen_pengguna">
                        <i class="ti-desktop mr-2 list-group-icon"></i>Manajemen Pengguna
                    </a>
                    <a href="" class="list-group-item d-flex align-items-center" id="pegawai">
                        <i class="ti-user mr-2 list-group-icon"></i>Pegawai
                        <span class="small ml-auto">10</span>
                    </a>
                    <a href="" class="list-group-item d-flex align-items-center" id="customer">
                        <i class="ti-user mr-2 list-group-icon"></i>Customer
                        <span class="small ml-auto">10</span>
                    </a>
                    <a href="" class="list-group-item d-flex align-items-center" id="vendor">
                        <i class="ti-star mr-2 list-group-icon"></i>Vendor
                        <span class="small ml-auto">10</span>
                    </a>
                    <a href="" class="list-group-item d-flex align-items-center" id="kendaraan">
                        <i class="ti-car mr-2 list-group-icon"></i>Kendaraan
                        <span class="small ml-auto">10</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-10 app-content">
        <?php echo $__env->yieldContent('content-data-master'); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-script'); ?>
    <script src="<?php echo e(asset('vendors/prism/prism.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyek\rental-mobil\resources\views/data_master.blade.php ENDPATH**/ ?>