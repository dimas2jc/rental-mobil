<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rental Mobil</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/media/image/favicon.png')); ?>"/>

    <!-- Main css -->
    <link rel="stylesheet" href="<?php echo e(asset('vendors/bundle.css')); ?>" type="text/css">

    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Daterangepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('vendors/datepicker/daterangepicker.css')); ?>" type="text/css">

    <!-- DataTable -->
    <link rel="stylesheet" href="<?php echo e(asset('vendors/dataTable/datatables.min.css')); ?>" type="text/css">

    <!-- App css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.min.css')); ?>" type="text/css">

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <?php echo $__env->yieldContent('extra-css'); ?>
</head>
<body class="small-navigation">
<!-- Preloader -->
<div class="preloader">
    <div class="preloader-icon"></div>
    <span>Loading...</span>
</div>
<!-- ./ Preloader -->

<!-- Layout wrapper -->
<div class="layout-wrapper">

    <!-- Header -->
    <?php echo $__env->make('layouts.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ./ Header -->

    <!-- Content wrapper -->
    <div class="content-wrapper">
        <!-- begin::navigation -->
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end::navigation -->

        <!-- Content body -->
        <div class="content-body">
            <!-- Content -->
            <div class="content web-app">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- ./ Content -->

            <!-- Footer -->
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- ./ Footer -->
        </div>
        <!-- ./ Content body -->
    </div>
    <!-- ./ Content wrapper -->
</div>
<!-- ./ Layout wrapper -->

    <!-- Main scripts -->
    <script src="<?php echo e(asset('vendors/bundle.js')); ?>"></script>

    <!-- Apex chart -->
    <script src="<?php echo e(asset('vendors/charts/apex/apexcharts.min.js')); ?>"></script>

    <!-- Daterangepicker -->
    <script src="<?php echo e(asset('vendors/datepicker/daterangepicker.js')); ?>"></script>

    <!-- DataTable -->
    <script src="<?php echo e(asset('vendors/dataTable/datatables.min.js')); ?>"></script>

    <!-- Dashboard scripts -->
    <script src="<?php echo e(asset('assets/js/examples/pages/dashboard.js')); ?>"></script>

    <!-- App scripts -->
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('extra-script'); ?>

</body>
</html>
<?php /**PATH D:\Proyek\rental-mobil\resources\views/layouts/app.blade.php ENDPATH**/ ?>