<footer class="content-footer">
    <?php if($data != null): ?>
        <div>© <?php echo date("Y"); ?> All Right Reserved - <a href="#" target="_blank"><?php echo e($data->NAME_COMPANY); ?></a></div>
    <?php else: ?>
        <div>© <?php echo date("Y"); ?> All Right Reserved - <a href="#" target="_blank">Sistem Informasi Rental</a></div>
    <?php endif; ?>
    <!-- <div>
        <nav class="nav">
            <a href="https://themeforest.net/licenses/standard" class="nav-link">Licenses</a>
            <a href="#" class="nav-link">Change Log</a>
            <a href="#" class="nav-link">Get Help</a>
        </nav>
    </div> -->
</footer>
<?php /**PATH D:\Proyek\rental-mobil\resources\views/layouts/footer.blade.php ENDPATH**/ ?>